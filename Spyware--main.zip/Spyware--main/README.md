Spyware with python :

Requirements:
- an idle (pycharm)
- modules such as : "pynput"
- basic knowledge of python


The written code easy to understand , it just for Educational purpose 
